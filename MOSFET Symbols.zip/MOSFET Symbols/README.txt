	***************************************************
	***************************************************
	**  need *.asy files and associated *.lib files  **
	**       in respective folders listed            **
	***************************************************
	***************************************************


Typical File Path   -->   C:/Program Files/LTC/LTspiceXVII/lib/sub/
-----------------------------------------------------------
zvn3306a.lib.txt    <—— ** Remove the .txt extensions ** 
zvp3306a.lib.txt       (Google flags .lib files as malicious)

Typical File Path   -->   C:/Program Files/LTC/LTspiceXVII/lib/sym/
-----------------------------------------------------------
ZVN3306A.asy
ZVP3306A.asy

(if there is any doubt - the file path is displayed when adding new
 components, i.e. voltage source, to the schematic)